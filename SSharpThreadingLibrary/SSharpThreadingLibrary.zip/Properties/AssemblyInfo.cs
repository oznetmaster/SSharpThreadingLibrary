﻿using System.Reflection;

[assembly: AssemblyTitle ("SSharpThreadingLibrary")]
[assembly: AssemblyCompany ("")]
[assembly: AssemblyProduct ("SSharpThreadingLibrary")]
[assembly: AssemblyCopyright ("Copyright ©  2014")]
[assembly: AssemblyVersion ("1.0.0.*")]

